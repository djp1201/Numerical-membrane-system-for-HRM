x = 0.990
y = 0.847
print(pow(x,1/2))
print(pow(y,1/3))
b1 = min(pow(x,1/2),pow(y,1/3))
print(b1)


print("---------")
x15 = 0.5
print(pow(x15,1/4))